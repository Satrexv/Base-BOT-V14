module.exports = {

    token: "nah",
    suggestid: "1026562149511864382"
}