const fs = require("fs")
const mongoose = require("mongoose")

module.exports = async bot => {

    mongoose.connect("mongodb+srv://Satrex:Satrex2893@symbiote.4z9sew5.mongodb.net/Symbiote", { useNewUrlParser: true, useUnifiedTopology: true })
    mongoose.connection.on("connected", () => {
        console.log("DB connectée")
    })
    
}