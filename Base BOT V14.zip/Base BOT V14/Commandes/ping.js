const Discord = require("discord.js")

module.exports = {

    name: "ping",
    description: "Affiche la latence du BOT",
    permission: "Aucune",
    dm: true,
    category: "Informations",
    async run(bot, message, args) {


       await message.reply(`L'attence du bot : \`${bot.ws.ping}\``)
    }
}