const Discord = require("discord.js")
const loadSlashCommands = require("../Loaders/loadSlashCommands")
const { ActivityType } = require("discord.js");

module.exports = async bot => {

    console.log(`${bot.user.tag} est bien en ligne !`)

    await loadSlashCommands (bot)

    const statuses = [
        "💻 Satrex#9999",
        "💥 .gg/theverse",
    ]
    let i = 0
    setInterval(() => {
        bot.user.setActivity(statuses[i], { type: Discord.ActivityType.Watching})
        i = ++i % statuses.length
    }, 1e4)
    bot.user.setStatus("online")
}
