Si vous avez un problème, rejoignez discord.gg/theverse et DM @Satrex#9999

Base d'un BOT Discord en SlashCommand en V14 fait en JavaScript.