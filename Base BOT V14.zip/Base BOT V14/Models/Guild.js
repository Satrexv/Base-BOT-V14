const mongoose = require("mongoose");

const guildShema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    guildID: String,
    guildName: String,
    Paypal: {
        "type": String,
        "default": "https://paypal.me/SatrexAnime"
    },
    Bitcoin: {
        "type": String,
        "default": "bc1qqyktnn7t83aezlnwxamm7r4d08a7at635knx7j"
    },
    Ethereum: {
        "type": String,
        "default": "0xeCb403C5685E1A80a17096Cc8c1C02ba9AdAd77B"
    },
    Litecoin: {
        "type": String,
        "default": "ltc1q86vqgl83ehzta8ww3fy2238xsfcgnhjfgucjsk"
    },
    Anti: {
        "type": Object,
        "default": {
            "bot": true,
            "channel": true,
            "everyone": true,
            "lien": true,
            "ban": true,
            "kick": true,
            "webhook": true,
            "spam": true
        }
    }
})



module.exports = mongoose.model("Guild", guildShema)