const mongoose = require("mongoose");

const guildShema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    guildID: String,
    userID: String,
    warnID: String,
    date: {
        "type": String,
        "default": ""
    },
    auteur: {
        "type": String,
        "default": ""
    },
    raison: {
        "type": String,
        "default": ""
    }
})

module.exports = mongoose.model("Warn", guildShema)