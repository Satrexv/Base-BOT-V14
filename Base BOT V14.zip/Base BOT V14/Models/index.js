module.exports = {
    Guild: require("../Models/Guild.js"),
    Warn: require("../Models/Warn.js")
}