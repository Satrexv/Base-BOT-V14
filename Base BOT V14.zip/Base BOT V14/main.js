const Discord = require("discord.js")
const intents = new Discord.IntentsBitField(3276799)
const bot = new Discord.Client({ intents })
const loadCommands = require("./Loaders/loadCommands")
const loadEvents = require("./Loaders/loadEvents")
const config = require('./config')
const mongodb = require("./Loaders/mongodb.js")

bot.commands = new Discord.Collection()
bot.color = "#020000";
bot.function  = {
    createID: require("./Fonctions/createId")
}

bot.login(config.token)
loadCommands(bot)
loadEvents(bot)
mongodb(bot)